#ifndef RATP_H_INCLUDED
#define RATP_H_INCLUDED

float computePrice(int age,int tourist);

#endif // RATP_H_INCLUDED
